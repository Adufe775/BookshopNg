import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number | string, currency: string = "₦") {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  return `${currency}${num.toFixed(2)}`;
}

export function formatDate(dateString: string | Date) {
  const date = typeof dateString === "string" ? new Date(dateString) : dateString;
  return date.toLocaleDateString("en-NG", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export function truncateText(text: string, maxLength: number) {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + "...";
}

export const billTypes = [
  { id: "airtime", name: "Airtime", icon: "fa-mobile-alt" },
  { id: "data", name: "Data", icon: "fa-wifi" },
  { id: "gotv", name: "GOTV", icon: "fa-tv" },
  { id: "electricity", name: "Electricity", icon: "fa-bolt" },
];
