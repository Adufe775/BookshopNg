import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { formatDate, formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/layout/header";
import BottomNavigation from "@/components/layout/bottom-navigation";
import { AlertCircle, BookOpen, Download, CheckCircle, Clock } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";

export default function MyBooks() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const { data: orders, isLoading } = useQuery({
    queryKey: ['/api/orders'],
    enabled: isAuthenticated,
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-300 border-yellow-300">
          <Clock className="w-3 h-3 mr-1" />
          Pending
        </Badge>;
      case 'confirmed':
        return <Badge variant="outline" className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300 border-blue-300">
          <CheckCircle className="w-3 h-3 mr-1" />
          Confirmed
        </Badge>;
      case 'delivered':
        return <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 border-green-300">
          <Download className="w-3 h-3 mr-1" />
          Ready
        </Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-300 border-red-300">
          <AlertCircle className="w-3 h-3 mr-1" />
          Cancelled
        </Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="flex-1 container max-w-5xl mx-auto px-4 py-4">
        <h1 className="text-2xl font-bold mb-4">My Books</h1>
        
        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Books</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="available">Available</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-1/2 mt-2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-1/3" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : !orders || orders.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium">No books purchased yet</h3>
                <p className="text-gray-500 mt-2">
                  When you purchase books, they will appear here for download
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order: any) => (
                  <Card key={order.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{order.book?.title}</CardTitle>
                          <CardDescription>By {order.book?.author}</CardDescription>
                        </div>
                        {getStatusBadge(order.status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Order Date</p>
                          <p>{formatDate(order.createdAt)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Amount</p>
                          <p>{formatCurrency(order.amount)}</p>
                        </div>
                      </div>
                      
                      {order.status === 'delivered' && (
                        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-md mt-2">
                          <p className="text-sm text-green-800 dark:text-green-300 mb-2">
                            <CheckCircle className="inline-block w-4 h-4 mr-1" /> 
                            Your book is ready for download
                          </p>
                          {order.downloadExpiry && (
                            <p className="text-xs text-green-700 dark:text-green-400">
                              Link expires on {formatDate(order.downloadExpiry)}
                            </p>
                          )}
                        </div>
                      )}
                      
                      {order.status === 'pending' && (
                        <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-md mt-2">
                          <p className="text-sm text-yellow-800 dark:text-yellow-300">
                            <Clock className="inline-block w-4 h-4 mr-1" /> 
                            Your payment is being processed. The book will be available for download once confirmed.
                          </p>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter>
                      {order.status === 'delivered' && order.pdfDownloadUrl ? (
                        <Button className="w-full sm:w-auto" onClick={() => window.open(order.pdfDownloadUrl, '_blank')}>
                          <Download className="w-4 h-4 mr-2" /> Download PDF
                        </Button>
                      ) : (
                        <Button disabled className="w-full sm:w-auto">
                          <Clock className="w-4 h-4 mr-2" /> Awaiting Confirmation
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="pending">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-1/2 mt-2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : !orders || !orders.filter((o: any) => o.status === 'pending' || o.status === 'confirmed').length ? (
              <div className="text-center py-12">
                <Clock className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium">No pending books</h3>
                <p className="text-gray-500 mt-2">
                  You don't have any pending book orders
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders
                  .filter((order: any) => order.status === 'pending' || order.status === 'confirmed')
                  .map((order: any) => (
                    <Card key={order.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{order.book?.title}</CardTitle>
                            <CardDescription>By {order.book?.author}</CardDescription>
                          </div>
                          {getStatusBadge(order.status)}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Order Date</p>
                            <p>{formatDate(order.createdAt)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Amount</p>
                            <p>{formatCurrency(order.amount)}</p>
                          </div>
                        </div>
                        
                        <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-md mt-3">
                          <p className="text-sm text-yellow-800 dark:text-yellow-300">
                            <Clock className="inline-block w-4 h-4 mr-1" /> 
                            Your payment is being processed. The book will be available for download once confirmed.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="available">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-1/2 mt-2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-1/3" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : !orders || !orders.filter((o: any) => o.status === 'delivered').length ? (
              <div className="text-center py-12">
                <Download className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium">No books available for download</h3>
                <p className="text-gray-500 mt-2">
                  You don't have any books ready for download yet
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders
                  .filter((order: any) => order.status === 'delivered')
                  .map((order: any) => (
                    <Card key={order.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{order.book?.title}</CardTitle>
                            <CardDescription>By {order.book?.author}</CardDescription>
                          </div>
                          {getStatusBadge(order.status)}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4 mb-3">
                          <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Order Date</p>
                            <p>{formatDate(order.createdAt)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Amount</p>
                            <p>{formatCurrency(order.amount)}</p>
                          </div>
                        </div>
                        
                        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-md">
                          <p className="text-sm text-green-800 dark:text-green-300 mb-2">
                            <CheckCircle className="inline-block w-4 h-4 mr-1" /> 
                            Your book is ready for download
                          </p>
                          {order.downloadExpiry && (
                            <p className="text-xs text-green-700 dark:text-green-400">
                              Link expires on {formatDate(order.downloadExpiry)}
                            </p>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full sm:w-auto" onClick={() => window.open(order.pdfDownloadUrl, '_blank')}>
                          <Download className="w-4 h-4 mr-2" /> Download PDF
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
      
      {isMobile && <BottomNavigation />}
    </div>
  );
}