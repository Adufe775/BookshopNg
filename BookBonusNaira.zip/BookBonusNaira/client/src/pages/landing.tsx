import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Hero Section */}
      <div className="relative h-[50vh] overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1526243741027-444d633d7365?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=800" 
          alt="Book Store Banner" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
          <div className="p-6 text-white">
            <h1 className="text-3xl font-bold mb-2">Welcome to BookHub</h1>
            <p className="text-lg mb-4">Your ultimate destination for all books</p>
            <a href="/api/login">
              <Button className="bg-primary hover:bg-primary/90 text-white">
                Sign In to Continue
              </Button>
            </a>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6 text-center">Why Choose BookHub?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="card-hover">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-4 mx-auto">
                <i className="fas fa-book text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2 text-center">Vast Collection</h3>
              <p className="text-gray-600 text-center">Explore thousands of titles across multiple genres and categories.</p>
            </CardContent>
          </Card>
          
          <Card className="card-hover">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center text-secondary mb-4 mx-auto">
                <i className="fas fa-wallet text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2 text-center">Digital Wallet</h3>
              <p className="text-gray-600 text-center">Fund your account for seamless book purchases and bill payments.</p>
            </CardContent>
          </Card>
          
          <Card className="card-hover">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-500 mb-4 mx-auto">
                <i className="fas fa-gift text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2 text-center">Bonuses & Rewards</h3>
              <p className="text-gray-600 text-center">Earn bonuses by completing simple tasks and referring friends.</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary/5 py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Start Reading?</h2>
          <p className="text-gray-600 mb-6 max-w-xl mx-auto">Join BookHub today and discover your next favorite book. Create an account to get started.</p>
          <a href="/api/login">
            <Button className="bg-primary hover:bg-primary/90 text-white">
              Sign In Now
            </Button>
          </a>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <i className="fas fa-book-open text-primary text-xl"></i>
              <h2 className="ml-2 text-lg font-bold">BookHub</h2>
            </div>
            <div className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} BookHub. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
