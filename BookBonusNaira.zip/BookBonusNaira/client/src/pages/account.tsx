import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Account() {
  const { user } = useAuth();

  if (!user) {
    return <div>Please log in to view your account</div>;
  }

  return (
    <div className="container mx-auto px-4 py-4">
      <div className="flex items-center mb-6">
        <div className="w-20 h-20 bg-gray-300 rounded-full overflow-hidden">
          <img 
            src={user.profileImageUrl || `https://ui-avatars.com/api/?name=${user.firstName || user.email || "User"}`}
            alt="Profile picture" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="ml-4">
          <h2 className="text-xl font-bold">{user.firstName || user.email || "User"}</h2>
          <p className="text-sm text-gray-600">{user.email || ""}</p>
        </div>
        <button className="ml-auto bg-gray-100 p-2 rounded-full">
          <i className="fas fa-pencil-alt text-gray-600"></i>
        </button>
      </div>
      
      <Card className="bg-white rounded-lg shadow-sm divide-y">
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-500 mr-3">
            <i className="fas fa-book"></i>
          </div>
          <span className="text-sm">My Orders</span>
          <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
        </div>
        
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-500 mr-3">
            <i className="fas fa-heart"></i>
          </div>
          <span className="text-sm">Wishlist</span>
          <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
        </div>
        
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-500 mr-3">
            <i className="fas fa-wallet"></i>
          </div>
          <span className="text-sm">Payment Methods</span>
          <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
        </div>
        
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-500 mr-3">
            <i className="fas fa-map-marker-alt"></i>
          </div>
          <span className="text-sm">Delivery Addresses</span>
          <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
        </div>
        
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-500 mr-3">
            <i className="fas fa-bell"></i>
          </div>
          <span className="text-sm">Notifications</span>
          <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
        </div>
        
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-500 mr-3">
            <i className="fas fa-cog"></i>
          </div>
          <span className="text-sm">Settings</span>
          <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
        </div>
        
        <div className="p-4 flex items-center">
          <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-500 mr-3">
            <i className="fas fa-sign-out-alt"></i>
          </div>
          <a href="/api/logout" className="text-sm">Logout</a>
        </div>
      </Card>
      
      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-3">App Information</h3>
        <Card className="bg-white rounded-lg shadow-sm divide-y">
          <div className="p-4 flex items-center">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-500 mr-3">
              <i className="fas fa-info-circle"></i>
            </div>
            <span className="text-sm">About Us</span>
            <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
          </div>
          
          <div className="p-4 flex items-center">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-500 mr-3">
              <i className="fas fa-shield-alt"></i>
            </div>
            <span className="text-sm">Privacy Policy</span>
            <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
          </div>
          
          <div className="p-4 flex items-center">
            <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-500 mr-3">
              <i className="fas fa-file-alt"></i>
            </div>
            <span className="text-sm">Terms & Conditions</span>
            <i className="fas fa-chevron-right text-gray-400 ml-auto"></i>
          </div>
          
          <div className="p-4">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-500 mr-3">
                <i className="fas fa-headset"></i>
              </div>
              <span className="text-sm font-semibold">Customer Service</span>
            </div>
            <div className="mt-2 pl-11">
              <p className="text-sm text-gray-600">Email: candydot299@gmail.com</p>
              <p className="text-sm text-gray-600 mt-1">Response within 24 hours</p>
              <p className="text-sm text-gray-600 mt-1">Payments processed within 48 hours</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
