import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

export default function BillPayment() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState("airtime");
  
  // Airtime form state
  const [airtimeProvider, setAirtimeProvider] = useState("MTN");
  const [airtimeNumber, setAirtimeNumber] = useState("");
  const [airtimeAmount, setAirtimeAmount] = useState("");
  
  // Data form state
  const [dataProvider, setDataProvider] = useState("MTN");
  const [dataNumber, setDataNumber] = useState("");
  const [dataAmount, setDataAmount] = useState("");
  
  // Withdraw form state
  const [accountNumber, setAccountNumber] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountName, setAccountName] = useState("");
  
  const billPaymentMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/bill-payments", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bill-payments"] });
      
      toast({
        title: "Request Submitted",
        description: "Your request has been sent to the admin for processing.",
        variant: "default",
      });
      
      // Reset form based on current tab
      if (tab === "airtime") {
        setAirtimeNumber("");
        setAirtimeAmount("");
      } else if (tab === "data") {
        setDataNumber("");
        setDataAmount("");
      } else {
        setAccountNumber("");
        setWithdrawAmount("");
        setBankName("");
        setAccountName("");
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit request",
        variant: "destructive",
      });
    }
  });
  
  const handleAirtimeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(airtimeAmount);
    if (!airtimeNumber || !airtimeAmount || isNaN(amount)) {
      toast({
        title: "Missing Information",
        description: "Please fill all fields with valid information",
        variant: "destructive",
      });
      return;
    }
    
    billPaymentMutation.mutate({
      billType: "airtime",
      serviceProvider: airtimeProvider,
      billReference: airtimeNumber,
      amount
    });
  };
  
  const handleDataSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(dataAmount);
    if (!dataNumber || !dataAmount || isNaN(amount)) {
      toast({
        title: "Missing Information",
        description: "Please fill all fields with valid information",
        variant: "destructive",
      });
      return;
    }
    
    billPaymentMutation.mutate({
      billType: "data",
      serviceProvider: dataProvider,
      billReference: dataNumber,
      amount
    });
  };
  
  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(withdrawAmount);
    if (!accountNumber || !withdrawAmount || !bankName || !accountName || isNaN(amount)) {
      toast({
        title: "Missing Information",
        description: "Please fill all fields with valid information",
        variant: "destructive",
      });
      return;
    }
    
    const withdrawInfo = `${bankName} | ${accountName} | ${accountNumber}`;
    billPaymentMutation.mutate({
      billType: "withdraw",
      billReference: withdrawInfo,
      amount
    });
  };
  
  const formatBalance = (balance: string | number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(Number(balance));
  };
  
  return (
    <div className="container max-w-xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Pay Bills & Withdraw</h1>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Your Balance</CardTitle>
          <CardDescription>
            Available balance for transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-primary">
            {user ? formatBalance(user.balance) : "₦0.00"}
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="airtime" value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="airtime">Airtime</TabsTrigger>
          <TabsTrigger value="data">Data</TabsTrigger>
          <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
        </TabsList>
        
        <TabsContent value="airtime">
          <Card>
            <CardHeader>
              <CardTitle>Buy Airtime</CardTitle>
              <CardDescription>
                Purchase airtime for any mobile number
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAirtimeSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="provider">Select Network</Label>
                  <RadioGroup 
                    id="provider"
                    value={airtimeProvider} 
                    onValueChange={setAirtimeProvider}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="MTN" id="mtn" />
                      <Label htmlFor="mtn">MTN</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Airtel" id="airtel" />
                      <Label htmlFor="airtel">Airtel</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="9mobile" id="9mobile" />
                      <Label htmlFor="9mobile">9mobile</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    placeholder="Enter phone number"
                    value={airtimeNumber}
                    onChange={(e) => setAirtimeNumber(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (₦)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount"
                    value={airtimeAmount}
                    onChange={(e) => setAirtimeAmount(e.target.value)}
                    min="50"
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={billPaymentMutation.isPending}
                >
                  {billPaymentMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Buy Airtime"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="data">
          <Card>
            <CardHeader>
              <CardTitle>Buy Data</CardTitle>
              <CardDescription>
                Purchase data bundle for any mobile number
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleDataSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="data-provider">Select Network</Label>
                  <RadioGroup 
                    id="data-provider"
                    value={dataProvider} 
                    onValueChange={setDataProvider}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="MTN" id="data-mtn" />
                      <Label htmlFor="data-mtn">MTN</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Airtel" id="data-airtel" />
                      <Label htmlFor="data-airtel">Airtel</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="9mobile" id="data-9mobile" />
                      <Label htmlFor="data-9mobile">9mobile</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data-phone">Phone Number</Label>
                  <Input
                    id="data-phone"
                    placeholder="Enter phone number"
                    value={dataNumber}
                    onChange={(e) => setDataNumber(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data-amount">Amount (₦)</Label>
                  <Input
                    id="data-amount"
                    type="number"
                    placeholder="Enter amount"
                    value={dataAmount}
                    onChange={(e) => setDataAmount(e.target.value)}
                    min="50"
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={billPaymentMutation.isPending}
                >
                  {billPaymentMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Buy Data"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="withdraw">
          <Card>
            <CardHeader>
              <CardTitle>Withdraw Funds</CardTitle>
              <CardDescription>
                Withdraw funds to your bank account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleWithdrawSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="bank-name">Bank Name</Label>
                  <Input
                    id="bank-name"
                    placeholder="Enter bank name"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="account-name">Account Name</Label>
                  <Input
                    id="account-name"
                    placeholder="Enter account name"
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="account-number">Account Number</Label>
                  <Input
                    id="account-number"
                    placeholder="Enter account number"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="withdraw-amount">Amount (₦)</Label>
                  <Input
                    id="withdraw-amount"
                    type="number"
                    placeholder="Enter amount"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    min="100"
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={billPaymentMutation.isPending}
                >
                  {billPaymentMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Withdraw Funds"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}