import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Book, Category } from "@shared/schema";
import BookCard from "@/components/books/book-card";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Categories() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: categories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: books, isLoading: isBooksLoading } = useQuery<Book[]>({
    queryKey: ["/api/books", selectedCategory ? `category/${selectedCategory}` : "all"],
    queryFn: async () => {
      if (selectedCategory) {
        const res = await fetch(`/api/books/category/${selectedCategory}`);
        return res.json();
      } else {
        const res = await fetch("/api/books");
        return res.json();
      }
    }
  });

  const { data: searchResults, isLoading: isSearchLoading } = useQuery<Book[]>({
    queryKey: ["/api/books/search", searchQuery],
    queryFn: async () => {
      const res = await fetch(`/api/books/search/${encodeURIComponent(searchQuery)}`);
      return res.json();
    },
    enabled: searchQuery.length > 2
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The search is triggered automatically by the query
  };

  const displayedBooks = searchQuery.length > 2 ? searchResults : books;

  return (
    <div className="container mx-auto px-4 py-4">
      <h2 className="text-xl font-bold mb-4">Categories</h2>
      
      {/* Search Bar */}
      <form onSubmit={handleSearch} className="mb-4">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search books..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2"
          />
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <i className="fas fa-search text-gray-400"></i>
          </div>
          <Button 
            type="submit" 
            className="absolute inset-y-0 right-0 bg-primary hover:bg-primary/90 text-white rounded-r-md px-4"
          >
            Search
          </Button>
        </div>
      </form>
      
      {/* Categories Grid */}
      {!searchQuery && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 mb-6">
          {isCategoriesLoading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-lg h-48 animate-pulse"></div>
            ))
          ) : categories && categories.length > 0 ? (
            categories.map((category) => (
              <div 
                key={category.id} 
                className="bg-white rounded-lg overflow-hidden shadow-md cursor-pointer"
                onClick={() => setSelectedCategory(category.id)}
              >
                <img 
                  src={category.imageUrl || "https://images.unsplash.com/photo-1526243741027-444d633d7365?ixlib=rb-4.0.3"}
                  alt={category.name} 
                  className="w-full h-28 object-cover"
                />
                <div className="p-3">
                  <h3 className="text-sm font-medium">{category.name}</h3>
                  <p className="text-xs text-gray-500 mt-1">{category.bookCount} books</p>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full">
              <Card>
                <CardContent className="py-10 text-center">
                  <p className="text-gray-500">No categories found</p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}
      
      {/* Book List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">
            {searchQuery.length > 2 
              ? `Search Results for "${searchQuery}"` 
              : selectedCategory && categories 
                ? `${categories.find(c => c.id === selectedCategory)?.name || 'Selected Category'} Books` 
                : 'All Books'}
          </h2>
          {selectedCategory && !searchQuery && (
            <Button 
              variant="outline" 
              onClick={() => setSelectedCategory(null)}
              className="text-sm"
            >
              View All
            </Button>
          )}
        </div>
        
        {searchQuery.length > 2 && isSearchLoading ? (
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="book-card h-48 animate-pulse bg-gray-200"></div>
            ))}
          </div>
        ) : searchQuery.length > 2 && searchResults && searchResults.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center">
              <p className="text-gray-500">No books found matching "{searchQuery}"</p>
            </CardContent>
          </Card>
        ) : isBooksLoading ? (
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
            {Array(12).fill(0).map((_, i) => (
              <div key={i} className="book-card h-48 animate-pulse bg-gray-200"></div>
            ))}
          </div>
        ) : displayedBooks && displayedBooks.length > 0 ? (
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
            {displayedBooks.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-10 text-center">
              <p className="text-gray-500">No books found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
