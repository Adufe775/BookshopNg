import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { CartItem, Book } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function Cart() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  // Fetch cart items
  const { data: cartItems, isLoading: isCartLoading } = useQuery<CartItem[]>({
    queryKey: ["/api/cart"],
    enabled: !!user
  });

  // Fetch books for each cart item
  const { data: books, isLoading: isBooksLoading } = useQuery<Book[]>({
    queryKey: ["/api/books"],
    enabled: !!user
  });

  // Map cart items to books
  const cartWithBooks = cartItems?.map(item => {
    const book = books?.find(b => b.id === item.bookId);
    return { ...item, book };
  });

  // Calculate cart totals
  const subtotal = cartWithBooks?.reduce((total, item) => {
    const price = parseFloat(item.book?.price.toString() || "0");
    return total + (price * item.quantity);
  }, 0) || 0;

  const discount = 0; // You could calculate discounts here
  const total = subtotal - discount;

  // Mutations for cart operations
  const updateItemMutation = useMutation({
    mutationFn: ({ id, quantity }: { id: number, quantity: number }) => {
      return apiRequest("PUT", `/api/cart/${id}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update item",
        variant: "destructive",
      });
    }
  });

  const removeItemMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/cart/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove item",
        variant: "destructive",
      });
    }
  });

  const checkoutMutation = useMutation({
    mutationFn: () => {
      // In a real app, you'd likely have a checkout endpoint
      // This is a simplified version that creates a transaction
      return apiRequest("POST", "/api/transactions", {
        amount: -total,
        type: "book_purchase",
        description: "Book purchase"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setIsCheckingOut(false);
      toast({
        title: "Success",
        description: "Your order has been placed successfully",
        variant: "default",
      });
    },
    onError: (error: any) => {
      setIsCheckingOut(false);
      toast({
        title: "Error",
        description: error.message || "Checkout failed",
        variant: "destructive",
      });
    }
  });

  const handleUpdateQuantity = (id: number, currentQuantity: number, change: number) => {
    const newQuantity = currentQuantity + change;
    if (newQuantity < 1) return;
    updateItemMutation.mutate({ id, quantity: newQuantity });
  };

  const handleRemoveItem = (id: number) => {
    removeItemMutation.mutate(id);
  };

  const handleCheckout = () => {
    if (!user || !cartItems || cartItems.length === 0) return;
    
    if (parseFloat(user.balance.toString()) < total) {
      toast({
        title: "Insufficient Balance",
        description: "Please fund your wallet to complete this purchase",
        variant: "destructive",
      });
      return;
    }
    
    setIsCheckingOut(true);
    checkoutMutation.mutate();
  };

  const isLoading = isCartLoading || isBooksLoading;

  return (
    <div className="container mx-auto px-4 py-4">
      <h2 className="text-xl font-bold mb-4">Your Cart</h2>
      
      {/* Empty Cart State */}
      {!isLoading && (!cartItems || cartItems.length === 0) && (
        <div id="empty-cart" className="text-center py-10">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-shopping-cart text-gray-400 text-3xl"></i>
          </div>
          <h3 className="text-lg font-medium text-gray-800 mb-2">Your cart is empty</h3>
          <p className="text-gray-500 text-sm mb-4">Start adding books to your cart</p>
          <Button className="bg-primary hover:bg-primary/90 text-white">
            Browse Books
          </Button>
        </div>
      )}
      
      {/* Cart Items */}
      {isLoading ? (
        <div className="animate-pulse space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      ) : cartWithBooks && cartWithBooks.length > 0 && (
        <div id="cart-items">
          {cartWithBooks.map((item) => (
            <div key={item.id} className="bg-white rounded-lg p-3 flex mb-3 shadow-sm">
              <img 
                src={item.book?.coverImage || "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3"}
                alt={item.book?.title || "Book cover"} 
                className="w-16 h-24 object-cover rounded-md"
              />
              <div className="ml-3 flex-1">
                <div className="flex justify-between">
                  <h3 className="text-sm font-medium">{item.book?.title || "Book Title"}</h3>
                  <button 
                    className="text-gray-400"
                    onClick={() => handleRemoveItem(item.id)}
                    disabled={removeItemMutation.isPending}
                  >
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-1">by {item.book?.author || "Author"}</p>
                <div className="flex items-center mt-2">
                  <button 
                    className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center"
                    onClick={() => handleUpdateQuantity(item.id, item.quantity, -1)}
                    disabled={updateItemMutation.isPending}
                  >
                    <i className="fas fa-minus text-xs"></i>
                  </button>
                  <span className="mx-3 text-sm">{item.quantity}</span>
                  <button 
                    className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center"
                    onClick={() => handleUpdateQuantity(item.id, item.quantity, 1)}
                    disabled={updateItemMutation.isPending}
                  >
                    <i className="fas fa-plus text-xs"></i>
                  </button>
                  <span className="ml-auto text-sm font-medium">
                    ₦{(parseFloat(item.book?.price.toString() || "0") * item.quantity).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}
          
          {/* Cart Summary */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-600">Subtotal</span>
              <span className="text-sm font-medium">₦{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-600">Discount</span>
              <span className="text-sm font-medium text-green-500">-₦{discount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-3 pt-2 border-t">
              <span className="text-base font-medium">Total</span>
              <span className="text-base font-bold">₦{total.toFixed(2)}</span>
            </div>
            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-white py-3 rounded-lg font-medium"
              onClick={handleCheckout}
              disabled={isCheckingOut || total <= 0}
            >
              {isCheckingOut ? "Processing..." : "Proceed to Checkout"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
