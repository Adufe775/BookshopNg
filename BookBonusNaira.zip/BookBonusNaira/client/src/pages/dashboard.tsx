import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import BalanceCard from "@/components/dashboard/balance-card";
import TikTokBonusModal from "@/components/dashboard/tiktok-bonus-modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Transaction } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

const fundWalletSchema = z.object({
  amount: z.number().min(100, { message: "Amount must be at least ₦100" })
});

const billPaymentSchema = z.object({
  billType: z.enum(["airtime", "data", "gotv", "electricity"]),
  billReference: z.string().min(1, { message: "Reference is required" }),
  amount: z.number().min(50, { message: "Amount must be at least ₦50" })
});

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isTikTokModalOpen, setIsTikTokModalOpen] = useState(false);
  const [fundModalOpen, setFundModalOpen] = useState(false);
  const [billModalOpen, setBillModalOpen] = useState(false);
  const [selectedBillType, setSelectedBillType] = useState<string | null>(null);

  const { data: transactions, isLoading: isTransactionsLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    enabled: !!user
  });

  const fundForm = useForm<z.infer<typeof fundWalletSchema>>({
    resolver: zodResolver(fundWalletSchema),
    defaultValues: {
      amount: 1000
    }
  });

  const billForm = useForm<z.infer<typeof billPaymentSchema>>({
    resolver: zodResolver(billPaymentSchema),
    defaultValues: {
      billType: "airtime",
      billReference: "",
      amount: 100
    }
  });

  const fundWalletMutation = useMutation({
    mutationFn: (data: z.infer<typeof fundWalletSchema>) => {
      return apiRequest("POST", "/api/transactions/fund", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setFundModalOpen(false);
      toast({
        title: "Success",
        description: "Your wallet has been funded successfully",
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to fund wallet",
        variant: "destructive",
      });
    }
  });

  const billPaymentMutation = useMutation({
    mutationFn: (data: z.infer<typeof billPaymentSchema>) => {
      return apiRequest("POST", "/api/bill-payments", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setBillModalOpen(false);
      toast({
        title: "Success",
        description: "Bill payment successful",
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process bill payment",
        variant: "destructive",
      });
    }
  });

  const handleFundWallet = (values: z.infer<typeof fundWalletSchema>) => {
    fundWalletMutation.mutate(values);
  };

  const handleBillPayment = (values: z.infer<typeof billPaymentSchema>) => {
    billPaymentMutation.mutate(values);
  };

  const handleSelectBillType = (type: string) => {
    billForm.setValue("billType", type as any);
    setSelectedBillType(type);
  };

  if (!user) {
    return <div>Please log in to view your dashboard</div>;
  }

  return (
    <div className="container mx-auto px-4 py-4">
      {/* User Profile Section */}
      <div className="flex items-center mb-6">
        <div className="w-16 h-16 bg-gray-300 rounded-full overflow-hidden">
          <img 
            src={user.profileImageUrl || "https://ui-avatars.com/api/?name=" + (user.firstName || user.email || "User")}
            alt="Profile picture" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="ml-4">
          <h2 className="text-lg font-bold">{user.firstName || user.email || "User"}</h2>
          <p className="text-sm text-gray-600">{user.email || ""}</p>
        </div>
        <button className="ml-auto text-gray-600">
          <i className="fas fa-cog text-xl"></i>
        </button>
      </div>

      {/* Wallet Balance Card */}
      <BalanceCard 
        balance={user.balance} 
        onFundWallet={() => setFundModalOpen(true)}
      />

      {/* Tasks Section */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-3">Earn Bonuses</h3>
        
        <div className="task-card">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-red-500">
              <i className="fab fa-tiktok text-lg"></i>
            </div>
            <div className="ml-3">
              <h4 className="text-sm font-medium">Follow on TikTok</h4>
              <p className="text-xs text-gray-500">Earn ₦50 bonus</p>
            </div>
          </div>
          <Button 
            onClick={() => setIsTikTokModalOpen(true)}
            disabled={user.gotTikTokBonus}
            className="bg-primary hover:bg-primary/90 text-white px-3 py-1.5 rounded-lg text-xs font-medium"
          >
            {user.gotTikTokBonus ? "Claimed" : "Follow"}
          </Button>
        </div>
        
        <div className="task-card">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-500">
              <i className="fas fa-user-plus text-lg"></i>
            </div>
            <div className="ml-3">
              <h4 className="text-sm font-medium">Refer a Friend</h4>
              <p className="text-xs text-gray-500">Earn ₦200 per referral</p>
            </div>
          </div>
          <Button className="bg-secondary hover:bg-secondary/90 text-white px-3 py-1.5 rounded-lg text-xs font-medium">
            Share
          </Button>
        </div>
      </div>

      {/* Bill Payments Section */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-3">Bill Payments</h3>
        <div className="grid grid-cols-4 gap-3">
          <div 
            className="bill-payment-card cursor-pointer"
            onClick={() => {
              handleSelectBillType("airtime");
              setBillModalOpen(true);
            }}
          >
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-purple-500 mb-1">
              <i className="fas fa-mobile-alt"></i>
            </div>
            <span className="text-xs">Airtime</span>
          </div>
          <div 
            className="bill-payment-card cursor-pointer"
            onClick={() => {
              handleSelectBillType("data");
              setBillModalOpen(true);
            }}
          >
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-500 mb-1">
              <i className="fas fa-wifi"></i>
            </div>
            <span className="text-xs">Data</span>
          </div>
          <div 
            className="bill-payment-card cursor-pointer"
            onClick={() => {
              handleSelectBillType("gotv");
              setBillModalOpen(true);
            }}
          >
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-500 mb-1">
              <i className="fas fa-tv"></i>
            </div>
            <span className="text-xs">GOTV</span>
          </div>
          <div 
            className="bill-payment-card cursor-pointer"
            onClick={() => {
              handleSelectBillType("electricity");
              setBillModalOpen(true);
            }}
          >
            <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-500 mb-1">
              <i className="fas fa-bolt"></i>
            </div>
            <span className="text-xs">Electricity</span>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold">Recent Transactions</h3>
          <a href="#" className="text-secondary text-sm">See All</a>
        </div>
        
        {isTransactionsLoading ? (
          <div className="animate-pulse space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        ) : transactions && transactions.length > 0 ? (
          transactions.map((transaction) => (
            <div key={transaction.id} className="bg-white rounded-lg p-3 flex items-center justify-between mb-2 shadow-sm">
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  transaction.type === 'wallet_funding' 
                    ? 'bg-green-100 text-green-500' 
                    : transaction.type === 'book_purchase' 
                    ? 'bg-blue-100 text-blue-500'
                    : transaction.type === 'bonus'
                    ? 'bg-yellow-100 text-yellow-500'
                    : 'bg-red-100 text-red-500'
                }`}>
                  <i className={`fas ${
                    transaction.type === 'wallet_funding' 
                      ? 'fa-wallet' 
                      : transaction.type === 'book_purchase' 
                      ? 'fa-book-open'
                      : transaction.type === 'bonus'
                      ? 'fa-gift'
                      : 'fa-receipt'
                  } text-sm`}></i>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium">{
                    transaction.type === 'wallet_funding' 
                      ? 'Wallet Funding' 
                      : transaction.type === 'book_purchase' 
                      ? 'Book Purchase'
                      : transaction.type === 'bonus'
                      ? 'Bonus Received'
                      : 'Bill Payment'
                  }</h4>
                  <p className="text-xs text-gray-500">{new Date(transaction.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
              <span className={`text-sm font-medium ${parseFloat(transaction.amount.toString()) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                {parseFloat(transaction.amount.toString()) > 0 ? '+' : ''}₦{Math.abs(parseFloat(transaction.amount.toString())).toFixed(2)}
              </span>
            </div>
          ))
        ) : (
          <Card>
            <CardContent className="py-6 text-center">
              <p className="text-gray-500">No transactions yet</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* TikTok Bonus Modal */}
      <TikTokBonusModal isOpen={isTikTokModalOpen} onClose={() => setIsTikTokModalOpen(false)} />

      {/* Fund Wallet Modal */}
      <Dialog open={fundModalOpen} onOpenChange={setFundModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Fund Your Wallet</DialogTitle>
            <DialogDescription>
              Enter the amount you'd like to add to your wallet balance.
            </DialogDescription>
          </DialogHeader>
          <Form {...fundForm}>
            <form onSubmit={fundForm.handleSubmit(handleFundWallet)} className="space-y-6">
              <FormField
                control={fundForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (₦)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="100" 
                        placeholder="1000" 
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormDescription>
                      Minimum amount is ₦100
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setFundModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={fundWalletMutation.isPending}>
                  {fundWalletMutation.isPending ? "Processing..." : "Fund Wallet"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Bill Payment Modal */}
      <Dialog open={billModalOpen} onOpenChange={setBillModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedBillType === "airtime" 
                ? "Buy Airtime" 
                : selectedBillType === "data" 
                ? "Buy Data" 
                : selectedBillType === "gotv" 
                ? "Pay GOTV" 
                : "Pay Electricity"}
            </DialogTitle>
            <DialogDescription>
              Enter the details to complete your payment.
            </DialogDescription>
          </DialogHeader>
          <Form {...billForm}>
            <form onSubmit={billForm.handleSubmit(handleBillPayment)} className="space-y-6">
              <FormField
                control={billForm.control}
                name="billReference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {selectedBillType === "airtime" || selectedBillType === "data" 
                        ? "Phone Number" 
                        : selectedBillType === "gotv" 
                        ? "IUC Number" 
                        : "Meter Number"}
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder={
                          selectedBillType === "airtime" || selectedBillType === "data" 
                            ? "08012345678" 
                            : selectedBillType === "gotv" 
                            ? "12345678901" 
                            : "12345678901"
                        } 
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={billForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (₦)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="50" 
                        placeholder="100" 
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormDescription>
                      Minimum amount is ₦50
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setBillModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={billPaymentMutation.isPending}>
                  {billPaymentMutation.isPending ? "Processing..." : "Pay Now"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
