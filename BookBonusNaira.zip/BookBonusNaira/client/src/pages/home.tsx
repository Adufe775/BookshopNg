import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import BookCard from "@/components/books/book-card";
import { Button } from "@/components/ui/button";
import TikTokBonusModal from "@/components/dashboard/tiktok-bonus-modal";
import { Book } from "@shared/schema";
import { useIp } from "@/hooks/use-ip";

export default function Home() {
  const { user } = useAuth();
  const { ipAddress, isExistingUser } = useIp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState("all");

  const { data: featuredBooks, isLoading: isFeaturedLoading } = useQuery<Book[]>({
    queryKey: ["/api/books", "featured"],
    queryFn: async () => {
      const res = await fetch("/api/books?limit=6");
      return res.json();
    }
  });

  const { data: newReleases, isLoading: isNewReleasesLoading } = useQuery<Book[]>({
    queryKey: ["/api/books", "new"],
    queryFn: async () => {
      const res = await fetch("/api/books?limit=6");
      return res.json();
    }
  });

  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  return (
    <div id="home-tab" className="tab-content pb-4">
      {/* Hero Banner Section */}
      <div className="relative overflow-hidden mb-4">
        <img 
          src="https://images.unsplash.com/photo-1526243741027-444d633d7365?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=300" 
          alt="Book Store Banner" 
          className="w-full h-40 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
          <div className="p-4 text-white">
            <h2 className="text-xl font-bold">Welcome to BookHub</h2>
            <p className="text-sm mt-1">Discover your next favorite read</p>
            <Button className="mt-3 bg-primary hover:bg-primary/90 text-white px-4 py-1.5 rounded-full text-sm font-medium">
              Explore Now
            </Button>
          </div>
        </div>
      </div>

      {/* Welcome Bonus Banner (For new users) */}
      {user && !user.gotTikTokBonus && (
        <div className="mx-4 mb-4 bg-secondary text-white p-3 rounded-lg shadow-md flex items-center justify-between">
          <div>
            <h3 className="font-semibold">New User Bonus!</h3>
            <p className="text-xs text-white/90">Follow us on TikTok and get ₦50 bonus</p>
          </div>
          <Button 
            onClick={() => setIsModalOpen(true)}
            className="bg-white text-secondary hover:bg-white/90 px-3 py-1 rounded-full text-xs font-semibold"
          >
            Claim Now
          </Button>
        </div>
      )}

      {/* Categories Scrollbar */}
      <div className="px-4 mb-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">Categories</h2>
          <a href="/categories" className="text-secondary text-sm">See All</a>
        </div>
        <div className="flex space-x-3 overflow-x-auto pb-2 hide-scrollbar">
          <Button 
            onClick={() => setActiveCategory("all")}
            variant={activeCategory === "all" ? "default" : "outline"}
            className={`whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-medium ${
              activeCategory === "all" ? "bg-primary text-white" : "bg-white text-dark"
            }`}
          >
            All Books
          </Button>
          {categories && categories.map((category: any) => (
            <Button
              key={category.id}
              onClick={() => setActiveCategory(category.id.toString())}
              variant={activeCategory === category.id.toString() ? "default" : "outline"}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-medium ${
                activeCategory === category.id.toString() ? "bg-primary text-white" : "bg-white text-dark"
              }`}
            >
              {category.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Featured Books */}
      <div className="px-4 mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">Featured Books</h2>
          <a href="/categories" className="text-secondary text-sm">See All</a>
        </div>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
          {isFeaturedLoading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="book-card h-48 animate-pulse bg-gray-200"></div>
            ))
          ) : (
            featuredBooks?.map((book) => (
              <BookCard key={book.id} book={book} />
            ))
          )}
        </div>
      </div>
      
      {/* New Releases */}
      <div className="px-4 mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">New Releases</h2>
          <a href="/categories" className="text-secondary text-sm">See All</a>
        </div>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
          {isNewReleasesLoading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="book-card h-48 animate-pulse bg-gray-200"></div>
            ))
          ) : (
            newReleases?.map((book) => (
              <BookCard key={book.id} book={book} />
            ))
          )}
        </div>
      </div>

      {/* TikTok Bonus Modal */}
      <TikTokBonusModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
