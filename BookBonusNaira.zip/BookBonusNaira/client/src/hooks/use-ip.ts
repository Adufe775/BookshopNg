import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

export function useIp() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/check-ip"],
    queryFn: async () => {
      const res = await fetch("/api/check-ip");
      if (!res.ok) {
        throw new Error("Failed to check IP");
      }
      return res.json();
    }
  });

  return {
    ipAddress: data?.ipAddress,
    isExistingUser: data?.isExistingUser,
    isLoading,
    error
  };
}
