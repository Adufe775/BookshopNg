import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { CartItem } from "@shared/schema";

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();
  
  const { data: cartItems } = useQuery<CartItem[]>({
    queryKey: ["/api/cart"],
  });

  const cartItemsCount = cartItems?.length || 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around z-20">
      <button 
        className={`bottom-nav-item py-2 ${location === '/' ? 'text-primary' : 'text-gray-500'}`}
        onClick={() => setLocation('/')}
      >
        <i className="fas fa-home bottom-nav-icon"></i>
        <span className="text-xs">Home</span>
      </button>
      
      <button 
        className={`bottom-nav-item py-2 ${location === '/categories' ? 'text-primary' : 'text-gray-500'}`}
        onClick={() => setLocation('/categories')}
      >
        <i className="fas fa-th-large bottom-nav-icon"></i>
        <span className="text-xs">Categories</span>
      </button>
      
      <button 
        className={`bottom-nav-item py-2 ${location === '/cart' ? 'text-primary' : 'text-gray-500'}`}
        onClick={() => setLocation('/cart')}
      >
        <i className="fas fa-shopping-cart bottom-nav-icon"></i>
        {cartItemsCount > 0 && (
          <Badge 
            className="absolute -top-1 right-1/4 bg-primary text-white text-xs h-5 w-5 flex items-center justify-center p-0"
            variant="destructive"
          >
            {cartItemsCount}
          </Badge>
        )}
        <span className="text-xs">Cart</span>
      </button>
      
      <button 
        className={`bottom-nav-item py-2 ${location === '/dashboard' ? 'text-primary' : 'text-gray-500'}`}
        onClick={() => setLocation('/dashboard')}
      >
        <i className="fas fa-wallet bottom-nav-icon"></i>
        <span className="text-xs">Dashboard</span>
      </button>
      
      <button 
        className={`bottom-nav-item py-2 ${location === '/bill-payment' ? 'text-primary' : 'text-gray-500'}`}
        onClick={() => setLocation('/bill-payment')}
      >
        <i className="fas fa-money-bill bottom-nav-icon"></i>
        <span className="text-xs">Pay Bills</span>
      </button>
      
      <button 
        className={`bottom-nav-item py-2 ${location === '/account' ? 'text-primary' : 'text-gray-500'}`}
        onClick={() => setLocation('/account')}
      >
        <i className="fas fa-user bottom-nav-icon"></i>
        <span className="text-xs">Account</span>
      </button>
    </div>
  );
}
