import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export default function Header() {
  const [location, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  
  const { data: unreadCount } = useQuery<{ count: number }>({
    queryKey: ['/api/notifications/unread-count'],
    enabled: !!isAuthenticated,
    refetchInterval: 30000, // Refresh every 30 seconds
  });
  
  return (
    <header className="sticky top-0 z-30 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <i className="fas fa-book-open text-primary text-xl"></i>
          <h1 className="ml-2 text-lg font-bold">BookHub</h1>
        </div>
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-gray-600"
            onClick={() => setLocation('/categories')}
          >
            <i className="fas fa-search text-lg"></i>
          </Button>
          
          {isAuthenticated && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-gray-600 relative"
              onClick={() => setLocation('/notifications')}
            >
              <i className="fas fa-bell text-lg"></i>
              {unreadCount && unreadCount.count > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {unreadCount.count > 9 ? '9+' : unreadCount.count}
                </span>
              )}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
