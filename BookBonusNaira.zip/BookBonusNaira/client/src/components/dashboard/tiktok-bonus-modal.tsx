import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TikTokBonusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TikTokBonusModal({ isOpen, onClose }: TikTokBonusModalProps) {
  const { toast } = useToast();

  const claimBonusMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/tiktok-bonus", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Bonus Claimed!",
        description: "₦50 has been added to your wallet.",
        variant: "default",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to claim bonus",
        variant: "destructive",
      });
    }
  });

  const handleFollow = () => {
    // Open TikTok in a new tab with the correct account
    window.open("https://www.tiktok.com/@adufe775?_t=ZM-8wdPAnQRx5x&_r=1", "_blank");
    
    // After user returns, claim the bonus
    claimBonusMutation.mutate();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white rounded-xl p-5 mx-4 w-full max-w-sm">
        <div className="text-center mb-4">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center text-red-500 mx-auto">
            <i className="fab fa-tiktok text-3xl"></i>
          </div>
          <h3 className="text-xl font-bold mt-3 mb-1">Follow us on TikTok</h3>
          <p className="text-gray-600 text-sm">Follow our TikTok account and earn ₦50 bonus!</p>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-lg mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-500">
              <i className="fab fa-tiktok text-xl"></i>
            </div>
            <div className="ml-3">
              <h4 className="text-sm font-medium">@adufe775</h4>
              <p className="text-xs text-gray-500">Follow to earn bonus</p>
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex gap-3">
          <Button 
            variant="outline"
            onClick={onClose}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleFollow} 
            disabled={claimBonusMutation.isPending}
            className="flex-1 bg-primary hover:bg-primary/90 text-white"
          >
            {claimBonusMutation.isPending ? "Processing..." : "Follow Now"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
