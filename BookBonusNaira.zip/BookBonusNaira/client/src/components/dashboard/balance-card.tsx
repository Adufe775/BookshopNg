import { Button } from "@/components/ui/button";

interface BalanceCardProps {
  balance: number | string;
  onFundWallet: () => void;
  onWithdraw?: () => void;
}

export default function BalanceCard({ 
  balance, 
  onFundWallet,
  onWithdraw 
}: BalanceCardProps) {
  const formattedBalance = typeof balance === 'number' 
    ? balance.toFixed(2) 
    : parseFloat(balance.toString()).toFixed(2);

  return (
    <div className="balance-card mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-base font-medium text-white/90">Wallet Balance</h3>
        <i className="fas fa-wallet text-lg"></i>
      </div>
      <div className="text-2xl font-bold">₦{formattedBalance}</div>
      <div className="flex mt-4 space-x-2">
        <Button 
          onClick={onFundWallet}
          className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm flex-1 py-2 rounded-lg text-sm"
        >
          <i className="fas fa-plus mr-1"></i> Fund Wallet
        </Button>
        {onWithdraw && (
          <Button 
            onClick={onWithdraw}
            className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm flex-1 py-2 rounded-lg text-sm"
          >
            <i className="fas fa-arrow-right mr-1"></i> Withdraw
          </Button>
        )}
      </div>
    </div>
  );
}
