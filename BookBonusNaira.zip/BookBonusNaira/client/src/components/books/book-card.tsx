import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Book } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface BookCardProps {
  book: Book;
}

export default function BookCard({ book }: BookCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const addToCartMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/cart", {
        bookId: book.id,
        quantity: 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: `${book.title} has been added to your cart`,
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add to cart",
        variant: "destructive",
      });
    }
  });

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      toast({
        title: "Not logged in",
        description: "Please log in to add items to your cart",
        variant: "destructive",
      });
      return;
    }
    addToCartMutation.mutate();
  };

  return (
    <div className="book-card card-hover relative group">
      <img 
        src={book.coverImage || "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3"}
        alt={book.title} 
        className="w-full h-36 object-cover"
      />
      <div className="p-2">
        <h3 className="text-xs font-medium line-clamp-1">{book.title}</h3>
        <p className="text-xs text-gray-500 mt-0.5">₦{parseFloat(book.price.toString()).toFixed(2)}</p>
      </div>
      <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
        <Button 
          className="bg-primary hover:bg-primary/90 text-white text-xs p-2"
          onClick={handleAddToCart}
          disabled={addToCartMutation.isPending}
        >
          Add to Cart
        </Button>
      </div>
    </div>
  );
}
