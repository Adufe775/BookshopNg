import {
  users,
  books,
  categories,
  cartItems,
  transactions,
  billPayments,
  ipAddresses,
  notifications,
  orders,
  type User,
  type UpsertUser,
  type Book,
  type Category,
  type CartItem,
  type Transaction,
  type BillPayment,
  type IpAddress,
  type Notification,
  type Order
} from "@shared/schema";
import { db } from "./db";
import { eq, and, like, asc, desc, sql, gte, lte, isNull, inArray } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByReferralCode(referralCode: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: number): Promise<User>;
  setTikTokBonus(userId: string): Promise<User>;
  generateReferralCode(userId: string): Promise<string>;
  processReferral(userId: string, referralCode: string): Promise<User>;
  
  // IP Address operations
  addUserIp(userId: string, ipAddress: string): Promise<IpAddress>;
  getUserByIp(ipAddress: string): Promise<User | undefined>;
  getIpsByUser(userId: string): Promise<IpAddress[]>;
  
  // Notification operations
  createNotification(userId: string, title: string, message: string, type: string, relatedId?: string): Promise<Notification>;
  getUserNotifications(userId: string, limit?: number, offset?: number): Promise<Notification[]>;
  getUnreadNotificationsCount(userId: string): Promise<number>;
  markNotificationAsRead(id: number): Promise<Notification>;
  markAllNotificationsAsRead(userId: string): Promise<void>;
  
  // Order operations for digital book delivery
  createOrder(userId: string, bookId: number, amount: number): Promise<Order>;
  getOrderById(id: number): Promise<Order | undefined>;
  getUserOrders(userId: string, limit?: number, offset?: number): Promise<Order[]>;
  updateOrderStatus(id: number, status: string, transactionId?: number): Promise<Order>;
  setPdfDownloadUrl(orderId: number, pdfUrl: string, expiryDate?: Date): Promise<Order>;

  // Book operations
  getBooks(limit?: number, offset?: number): Promise<Book[]>;
  getBookById(id: number): Promise<Book | undefined>;
  getBooksByCategory(categoryId: number, limit?: number, offset?: number): Promise<Book[]>;
  searchBooks(query: string, limit?: number, offset?: number): Promise<Book[]>;

  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;

  // Cart operations
  getCartItems(userId: string): Promise<CartItem[]>;
  addToCart(userId: string, bookId: number, quantity: number): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem>;
  removeFromCart(id: number): Promise<void>;
  clearCart(userId: string): Promise<void>;

  // Transaction operations
  createTransaction(userId: string, amount: number, type: string, description?: string): Promise<Transaction>;
  getUserTransactions(userId: string, limit?: number, offset?: number): Promise<Transaction[]>;

  // Bill payment operations
  createBillPayment(userId: string, billType: string, billReference: string, amount: number): Promise<BillPayment>;
  getBillPaymentsByUser(userId: string, limit?: number, offset?: number): Promise<BillPayment[]>;
  updateBillPaymentStatus(id: number, status: string, transactionId?: number): Promise<BillPayment>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        id: userData.id || '',
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        profileImageUrl: userData.profileImageUrl,
        balance: userData.balance || "0",
        gotTikTokBonus: userData.gotTikTokBonus || false
      } as any)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, amount: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        balance: sql`${users.balance} + ${amount}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async setTikTokBonus(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        gotTikTokBonus: true,
        balance: sql`${users.balance} + 50`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
  
  async generateReferralCode(userId: string): Promise<string> {
    // Generate a unique referral code based on user ID and a random string
    const randomStr = Math.random().toString(36).substring(2, 8).toUpperCase();
    const referralCode = `${randomStr}${userId.slice(-4)}`;
    
    // Save the referral code to the user
    await db
      .update(users)
      .set({ referralCode })
      .where(eq(users.id, userId));
      
    return referralCode;
  }
  
  async getUserByReferralCode(referralCode: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.referralCode, referralCode));
    return user;
  }
  
  async processReferral(userId: string, referralCode: string): Promise<User> {
    // Find the referrer
    const referrer = await this.getUserByReferralCode(referralCode);
    
    if (!referrer) {
      throw new Error("Invalid referral code");
    }
    
    if (referrer.id === userId) {
      throw new Error("You cannot refer yourself");
    }
    
    // Check if referrer has already reached max referrals (5)
    if (referrer.referralCount >= 5) {
      throw new Error("Referrer has reached maximum referrals");
    }
    
    // Update the new user with referrer info
    const [user] = await db
      .update(users)
      .set({
        referredBy: referrer.id,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
      
    // Update the referrer's count and give bonus
    const [updatedReferrer] = await db
      .update(users)
      .set({
        referralCount: sql`${users.referralCount} + 1`,
        balance: sql`${users.balance} + 50`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, referrer.id))
      .returning();
      
    // Create transaction record for the referrer
    await this.createTransaction(
      referrer.id,
      50,
      'bonus',
      `Referral bonus for inviting ${user.username || 'a new user'}`
    );
    
    return user;
  }

  // IP Address operations
  async addUserIp(userId: string, ipAddress: string): Promise<IpAddress> {
    try {
      const [ip] = await db
        .insert(ipAddresses)
        .values({
          userId,
          ipAddress,
        })
        .returning();
      return ip;
    } catch (error) {
      // If the IP already exists for this user, update the lastSeenAt
      const [ip] = await db
        .update(ipAddresses)
        .set({
          lastSeenAt: new Date(),
        })
        .where(
          and(
            eq(ipAddresses.userId, userId),
            eq(ipAddresses.ipAddress, ipAddress)
          )
        )
        .returning();
      return ip;
    }
  }

  async getUserByIp(ipAddress: string): Promise<User | undefined> {
    const [result] = await db
      .select({
        user: users,
      })
      .from(ipAddresses)
      .innerJoin(users, eq(ipAddresses.userId, users.id))
      .where(eq(ipAddresses.ipAddress, ipAddress));
    
    return result?.user;
  }

  async getIpsByUser(userId: string): Promise<IpAddress[]> {
    return await db
      .select()
      .from(ipAddresses)
      .where(eq(ipAddresses.userId, userId));
  }

  // Book operations
  async getBooks(limit = 20, offset = 0): Promise<Book[]> {
    return await db
      .select()
      .from(books)
      .limit(limit)
      .offset(offset);
  }

  async getBookById(id: number): Promise<Book | undefined> {
    const [book] = await db
      .select()
      .from(books)
      .where(eq(books.id, id));
    return book;
  }

  async getBooksByCategory(categoryId: number, limit = 20, offset = 0): Promise<Book[]> {
    return await db
      .select()
      .from(books)
      .where(eq(books.categoryId, categoryId))
      .limit(limit)
      .offset(offset);
  }

  async searchBooks(query: string, limit = 20, offset = 0): Promise<Book[]> {
    return await db
      .select()
      .from(books)
      .where(
        like(books.title, `%${query}%`)
      )
      .limit(limit)
      .offset(offset);
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db
      .select()
      .from(categories);
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));
    return category;
  }

  // Cart operations
  async getCartItems(userId: string): Promise<CartItem[]> {
    return await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.userId, userId));
  }

  async addToCart(userId: string, bookId: number, quantity: number): Promise<CartItem> {
    try {
      const [item] = await db
        .insert(cartItems)
        .values({
          userId,
          bookId,
          quantity,
        })
        .returning();
      return item;
    } catch (error) {
      // If the item already exists in the cart, update the quantity
      const [item] = await db
        .update(cartItems)
        .set({
          quantity: sql`${cartItems.quantity} + ${quantity}`,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(cartItems.userId, userId),
            eq(cartItems.bookId, bookId)
          )
        )
        .returning();
      return item;
    }
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem> {
    const [item] = await db
      .update(cartItems)
      .set({
        quantity,
        updatedAt: new Date(),
      })
      .where(eq(cartItems.id, id))
      .returning();
    return item;
  }

  async removeFromCart(id: number): Promise<void> {
    await db
      .delete(cartItems)
      .where(eq(cartItems.id, id));
  }

  async clearCart(userId: string): Promise<void> {
    await db
      .delete(cartItems)
      .where(eq(cartItems.userId, userId));
  }

  // Transaction operations
  async createTransaction(userId: string, amount: number, type: string, description?: string): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values({
        userId,
        amount: amount.toString(),
        type,
        description,
        reference: `TXREF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      })
      .returning();
    return transaction;
  }

  async getUserTransactions(userId: string, limit = 20, offset = 0): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt))
      .limit(limit)
      .offset(offset);
  }

  // Bill payment operations
  async createBillPayment(userId: string, billType: string, billReference: string, amount: number): Promise<BillPayment> {
    const [payment] = await db
      .insert(billPayments)
      .values({
        userId,
        billType,
        billReference,
        amount: amount.toString(),
      })
      .returning();
    return payment;
  }

  async getBillPaymentsByUser(userId: string, limit = 20, offset = 0): Promise<BillPayment[]> {
    return await db
      .select()
      .from(billPayments)
      .where(eq(billPayments.userId, userId))
      .orderBy(desc(billPayments.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async updateBillPaymentStatus(id: number, status: string, transactionId?: number): Promise<BillPayment> {
    const [payment] = await db
      .update(billPayments)
      .set({
        status,
        transactionId,
        updatedAt: new Date(),
      })
      .where(eq(billPayments.id, id))
      .returning();
    return payment;
  }
  
  // Notification operations
  async createNotification(userId: string, title: string, message: string, type: string, relatedId?: string): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values({
        userId,
        title,
        message,
        type,
        relatedId,
        isRead: false
      })
      .returning();
    return notification;
  }
  
  async getUserNotifications(userId: string, limit = 20, offset = 0): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(limit)
      .offset(offset);
  }
  
  async getUnreadNotificationsCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(notifications)
      .where(and(
        eq(notifications.userId, userId),
        eq(notifications.isRead, false)
      ));
    
    return result[0]?.count || 0;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification> {
    const [notification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return notification;
  }
  
  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, userId));
  }
  
  // Order operations for digital book delivery
  async createOrder(userId: string, bookId: number, amount: number): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values({
        userId,
        bookId,
        amount: amount.toString(), // Convert to string for decimal column
        status: 'pending'
      })
      .returning();
    return order;
  }
  
  async getOrderById(id: number): Promise<Order | undefined> {
    const [order] = await db
      .select()
      .from(orders)
      .where(eq(orders.id, id));
    return order;
  }
  
  async getUserOrders(userId: string, limit = 20, offset = 0): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt))
      .limit(limit)
      .offset(offset);
  }
  
  async updateOrderStatus(id: number, status: string, transactionId?: number): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set({
        status,
        transactionId,
        updatedAt: new Date()
      })
      .where(eq(orders.id, id))
      .returning();
    return order;
  }
  
  async setPdfDownloadUrl(orderId: number, pdfUrl: string, expiryDate?: Date): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set({
        pdfDownloadUrl: pdfUrl,
        downloadExpiry: expiryDate,
        status: 'delivered',
        updatedAt: new Date()
      })
      .where(eq(orders.id, orderId))
      .returning();
    return order;
  }
}

export const storage = new DatabaseStorage();
