import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { z, ZodError } from "zod";
import { 
  insertBookSchema,
  insertCategorySchema,
  insertCartItemSchema,
  insertTransactionSchema,
  insertBillPaymentSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Generate a referral code for the user if they don't have one
      if (user && !user.referralCode) {
        await storage.generateReferralCode(userId);
        const updatedUser = await storage.getUser(userId);
        res.json(updatedUser);
      } else {
        res.json(user);
      }
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  
  // Referral route
  app.post('/api/referral/use', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { referralCode } = req.body;
      
      if (!referralCode) {
        return res.status(400).json({ message: "Referral code is required" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.referredBy) {
        return res.status(400).json({ message: "You have already used a referral code" });
      }
      
      const updatedUser = await storage.processReferral(userId, referralCode);
      res.json({ user: updatedUser, message: "Referral code applied successfully" });
    } catch (error: any) {
      console.error("Error processing referral:", error);
      res.status(400).json({ message: error.message || "Failed to apply referral code" });
    }
  });

  // IP tracking middleware
  app.use(async (req: Request, res: Response, next) => {
    if (req.user) {
      try {
        const userId = (req.user as any).claims.sub;
        const ipAddress = req.ip || req.headers['x-forwarded-for'] as string || '0.0.0.0';
        await storage.addUserIp(userId, ipAddress);
      } catch (error) {
        console.error("Error tracking IP:", error);
      }
    }
    next();
  });

  // Check if IP exists
  app.get('/api/check-ip', async (req: Request, res: Response) => {
    try {
      const ipAddress = req.ip || req.headers['x-forwarded-for'] as string || '0.0.0.0';
      const existingUser = await storage.getUserByIp(ipAddress);
      
      res.json({
        isExistingUser: !!existingUser,
        ipAddress
      });
    } catch (error) {
      console.error("Error checking IP:", error);
      res.status(500).json({ message: "Failed to check IP" });
    }
  });

  // Book routes
  app.get('/api/books', async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      const books = await storage.getBooks(limit, offset);
      res.json(books);
    } catch (error) {
      console.error("Error fetching books:", error);
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.get('/api/books/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const book = await storage.getBookById(id);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      res.json(book);
    } catch (error) {
      console.error("Error fetching book:", error);
      res.status(500).json({ message: "Failed to fetch book" });
    }
  });

  app.get('/api/books/category/:categoryId', async (req: Request, res: Response) => {
    try {
      const categoryId = parseInt(req.params.categoryId) || 0;
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      const books = await storage.getBooksByCategory(categoryId, limit, offset);
      res.json(books);
    } catch (error) {
      console.error("Error fetching books by category:", error);
      res.status(500).json({ message: "Failed to fetch books by category" });
    }
  });

  app.get('/api/books/search/:query', async (req: Request, res: Response) => {
    try {
      const query = req.params.query;
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      const books = await storage.searchBooks(query, limit, offset);
      res.json(books);
    } catch (error) {
      console.error("Error searching books:", error);
      res.status(500).json({ message: "Failed to search books" });
    }
  });

  // Category routes
  app.get('/api/categories', async (req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get('/api/categories/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategoryById(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  // Cart routes (protected)
  app.get('/api/cart', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const cartItems = await storage.getCartItems(userId);
      res.json(cartItems);
    } catch (error) {
      console.error("Error fetching cart items:", error);
      res.status(500).json({ message: "Failed to fetch cart items" });
    }
  });

  app.post('/api/cart', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertCartItemSchema.parse({
        ...req.body,
        userId
      });
      
      const bookId = data.bookId || 0;
      const quantity = data.quantity || 1;
      const cartItem = await storage.addToCart(userId, bookId, quantity);
      res.status(201).json(cartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Error adding to cart:", error);
      res.status(500).json({ message: "Failed to add to cart" });
    }
  });

  app.put('/api/cart/:id', isAuthenticated, async (req: any, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { quantity } = req.body;
      
      if (typeof quantity !== 'number' || quantity < 1) {
        return res.status(400).json({ message: "Invalid quantity" });
      }
      
      const cartItem = await storage.updateCartItem(id, quantity);
      res.json(cartItem);
    } catch (error) {
      console.error("Error updating cart item:", error);
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  app.delete('/api/cart/:id', isAuthenticated, async (req: any, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.removeFromCart(id);
      res.status(204).end();
    } catch (error) {
      console.error("Error removing from cart:", error);
      res.status(500).json({ message: "Failed to remove from cart" });
    }
  });

  app.delete('/api/cart', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      await storage.clearCart(userId);
      res.status(204).end();
    } catch (error) {
      console.error("Error clearing cart:", error);
      res.status(500).json({ message: "Failed to clear cart" });
    }
  });

  // Transaction routes (protected)
  app.get('/api/transactions', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      const transactions = await storage.getUserTransactions(userId, limit, offset);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Fund wallet
  app.post('/api/transactions/fund', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { amount } = req.body;
      
      if (typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      // Create transaction record
      const transaction = await storage.createTransaction(userId, amount, 'wallet_funding', 'Wallet funding');
      
      // Update user balance
      const user = await storage.updateUserBalance(userId, amount);
      
      res.status(201).json({ transaction, user });
    } catch (error) {
      console.error("Error funding wallet:", error);
      res.status(500).json({ message: "Failed to fund wallet" });
    }
  });

  // Book order routes
  app.post('/api/orders', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId, amount } = req.body;
      
      if (!bookId || typeof bookId !== 'number') {
        return res.status(400).json({ message: "Book ID is required" });
      }
      
      if (typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const book = await storage.getBookById(bookId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      // Check if user has sufficient balance
      if (parseFloat(user.balance.toString()) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      // Create order
      const order = await storage.createOrder(userId, bookId, amount);
      
      // Create transaction
      const transaction = await storage.createTransaction(
        userId, 
        -amount, 
        'book_purchase', 
        `Purchase of book: ${book.title}`
      );
      
      // Update order with transaction ID
      const updatedOrder = await storage.updateOrderStatus(
        order.id, 
        'pending',
        transaction.id
      );
      
      // Update user balance
      const updatedUser = await storage.updateUserBalance(userId, -amount);
      
      // Create notification for the user
      await storage.createNotification(
        userId,
        'Book Purchase Pending',
        `Your purchase of "${book.title}" is being processed. You will receive the PDF link once the payment is confirmed.`,
        'purchase',
        order.id.toString()
      );
      
      // Also create notification for admin (which will be you)
      await storage.createNotification(
        userId, // Note: In a real system, this would be the admin's user ID
        'New Book Purchase',
        `A user has purchased "${book.title}" for ₦${amount}. Please review and confirm the order.`,
        'admin',
        order.id.toString()
      );
      
      res.status(201).json({ 
        order: updatedOrder, 
        transaction, 
        user: updatedUser,
        message: "Your book purchase is being processed. You will receive the PDF download link once payment is confirmed."
      });
    } catch (error) {
      console.error("Error creating book order:", error);
      res.status(500).json({ message: "Failed to create book order" });
    }
  });
  
  app.get('/api/orders', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      
      const orders = await storage.getUserOrders(userId, limit, offset);
      
      // Map orders to include book details
      const ordersWithBooks = await Promise.all(orders.map(async (order) => {
        const book = await storage.getBookById(order.bookId);
        return {
          ...order,
          book
        };
      }));
      
      res.json(ordersWithBooks);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });
  
  // Admin routes for managing orders and providing PDF links
  app.post('/api/admin/orders/:id/confirm', isAuthenticated, async (req: any, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      const { pdfUrl, expiryDays } = req.body;
      
      if (!orderId || isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      if (!pdfUrl) {
        return res.status(400).json({ message: "PDF URL is required" });
      }
      
      const order = await storage.getOrderById(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Calculate expiry date if provided
      let expiryDate: Date | undefined;
      if (expiryDays && typeof expiryDays === 'number') {
        expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + expiryDays);
      }
      
      // Update order with PDF link
      const updatedOrder = await storage.setPdfDownloadUrl(orderId, pdfUrl, expiryDate);
      
      // Create notification for the user
      await storage.createNotification(
        order.userId,
        'Book Download Ready',
        `Your purchase has been confirmed. You can now download "${(await storage.getBookById(order.bookId))?.title}".`,
        'purchase',
        order.id.toString()
      );
      
      res.json({ 
        order: updatedOrder,
        message: "Order confirmed and PDF link provided to user."
      });
    } catch (error) {
      console.error("Error confirming order:", error);
      res.status(500).json({ message: "Failed to confirm order" });
    }
  });
  
  // TikTok bonus
  app.post('/api/tiktok-bonus', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.gotTikTokBonus) {
        return res.status(400).json({ message: "TikTok bonus already claimed" });
      }
      
      // Update user and add bonus
      const updatedUser = await storage.setTikTokBonus(userId);
      
      // Create transaction record
      const transaction = await storage.createTransaction(userId, 50, 'bonus', 'TikTok follow bonus');
      
      res.json({ user: updatedUser, transaction });
    } catch (error) {
      console.error("Error claiming TikTok bonus:", error);
      res.status(500).json({ message: "Failed to claim TikTok bonus" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      
      const notifications = await storage.getUserNotifications(userId, limit, offset);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });
  
  app.get('/api/notifications/unread-count', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadNotificationsCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });
  
  app.post('/api/notifications/:id/read', isAuthenticated, async (req: any, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notification ID" });
      }
      
      const notification = await storage.markNotificationAsRead(id);
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });
  
  app.post('/api/notifications/read-all', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      await storage.markAllNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });
  
  // Bill payment routes
  app.get('/api/bill-payments', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string || '20');
      const offset = parseInt(req.query.offset as string || '0');
      const payments = await storage.getBillPaymentsByUser(userId, limit, offset);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching bill payments:", error);
      res.status(500).json({ message: "Failed to fetch bill payments" });
    }
  });

  app.post('/api/bill-payments', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { billType, serviceProvider, billReference, amount } = req.body;
      
      if (!['airtime', 'data', 'withdraw'].includes(billType)) {
        return res.status(400).json({ message: "Invalid bill type" });
      }
      
      if (typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (parseFloat(user.balance.toString()) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      // Create bill payment record
      const payment = await storage.createBillPayment(userId, billType, billReference, amount, serviceProvider);
      
      // Create transaction record
      let description = '';
      if (billType === 'withdraw') {
        description = `Withdrawal to: ${billReference}`;
      } else if (billType === 'airtime') {
        description = `${serviceProvider} Airtime for: ${billReference}`;
      } else if (billType === 'data') {
        description = `${serviceProvider} Data for: ${billReference}`;
      }
      
      const transaction = await storage.createTransaction(userId, -amount, 'bill_payment', description);
      
      // Update bill payment with transaction ID but keep status as pending
      const updatedPayment = await storage.updateBillPaymentStatus(payment.id, 'pending', transaction.id);
      
      // Update user balance
      const updatedUser = await storage.updateUserBalance(userId, -amount);
      
      // Create notification for the user
      let title = '';
      let message = '';
      
      if (billType === 'withdraw') {
        title = 'Withdrawal Request Received';
        message = `Your withdrawal request of ₦${amount} has been received and is being processed. It will be completed within 48 hours.`;
      } else if (billType === 'airtime') {
        title = 'Airtime Purchase';
        message = `Your ${serviceProvider} airtime purchase of ₦${amount} for ${billReference} is being processed.`;
      } else if (billType === 'data') {
        title = 'Data Purchase';
        message = `Your ${serviceProvider} data purchase of ₦${amount} for ${billReference} is being processed.`;
      }
      
      await storage.createNotification(
        userId,
        title,
        message,
        'bill_payment',
        payment.id.toString()
      );
      
      res.status(201).json({ 
        payment: updatedPayment, 
        transaction, 
        user: updatedUser,
        message: "Your request has been submitted and is pending approval by the admin."
      });
    } catch (error) {
      console.error("Error creating bill payment:", error);
      res.status(500).json({ message: "Failed to create bill payment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
