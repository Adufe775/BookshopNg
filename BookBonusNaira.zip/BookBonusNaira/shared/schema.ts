import {
  pgTable,
  text,
  serial,
  varchar,
  timestamp,
  jsonb,
  index,
  boolean,
  decimal,
  integer,
  primaryKey,
  uniqueIndex,
  foreignKey,
  inet
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  username: text("username").unique(),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0").notNull(),
  gotTikTokBonus: boolean("got_tiktok_bonus").default(false).notNull(),
  referralCount: integer("referral_count").default(0).notNull(),
  referralCode: varchar("referral_code").unique(),
  referredBy: varchar("referred_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// IP addresses table for tracking users
export const ipAddresses = pgTable("ip_addresses", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  ipAddress: inet("ip_address").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  lastSeenAt: timestamp("last_seen_at").defaultNow(),
}, (table) => {
  return {
    userIpIdx: uniqueIndex("user_ip_idx").on(table.userId, table.ipAddress),
  };
});

// Books table
export const books = pgTable("books", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  author: text("author").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  coverImage: text("cover_image"),
  description: text("description"),
  pdfUrl: text("pdf_url"),
  categoryId: integer("category_id").references(() => categories.id),
  stock: integer("stock").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  imageUrl: text("image_url"),
  bookCount: integer("book_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Cart items table
export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  bookId: integer("book_id").notNull().references(() => books.id),
  quantity: integer("quantity").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    userBookIdx: uniqueIndex("user_book_idx").on(table.userId, table.bookId),
  };
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  type: text("type").notNull(), // 'wallet_funding', 'book_purchase', 'bill_payment', 'bonus'
  description: text("description"),
  status: text("status").notNull().default("completed"), // 'pending', 'completed', 'failed'
  reference: text("reference").unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bill payments table
export const billPayments = pgTable("bill_payments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  billType: text("bill_type").notNull(), // 'airtime', 'data', 'withdraw'
  serviceProvider: text("service_provider"), // 'MTN', 'Airtel', '9mobile', null for withdraw
  billReference: text("bill_reference").notNull(), // phone number, account number, etc.
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // 'pending', 'completed', 'failed'
  transactionId: integer("transaction_id").references(() => transactions.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'bill_payment', 'withdrawal', 'purchase', 'system', etc.
  isRead: boolean("is_read").default(false).notNull(),
  relatedId: text("related_id"), // ID of related entity (transaction, order, etc.)
  createdAt: timestamp("created_at").defaultNow(),
});

// Orders table for digital book purchases
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  bookId: integer("book_id").notNull().references(() => books.id),
  status: text("status").notNull().default("pending"), // 'pending', 'confirmed', 'delivered', 'cancelled'
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  transactionId: integer("transaction_id").references(() => transactions.id),
  pdfDownloadUrl: text("pdf_download_url"), // Will be populated after payment confirmation
  downloadExpiry: timestamp("download_expiry"), // Optional expiry time for the download link
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users);
export const upsertUserSchema = z.object({
  id: z.string().optional(),
  email: z.string().email().optional().nullable(),
  firstName: z.string().optional().nullable(),
  lastName: z.string().optional().nullable(),
  profileImageUrl: z.string().optional().nullable(),
  username: z.string().optional().nullable(),
  balance: z.string().optional().default("0"),
  gotTikTokBonus: z.boolean().optional().default(false),
});
export const insertBookSchema = createInsertSchema(books).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCategorySchema = createInsertSchema(categories).omit({ id: true, createdAt: true });
export const insertCartItemSchema = createInsertSchema(cartItems).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true });
export const insertBillPaymentSchema = createInsertSchema(billPayments).omit({ id: true, createdAt: true, updatedAt: true });
export const insertIpAddressSchema = createInsertSchema(ipAddresses).omit({ id: true, createdAt: true, lastSeenAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true, updatedAt: true });

// Type definitions
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type Book = typeof books.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type CartItem = typeof cartItems.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type BillPayment = typeof billPayments.$inferSelect;
export type IpAddress = typeof ipAddresses.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Order = typeof orders.$inferSelect;
